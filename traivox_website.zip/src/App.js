import React from "react";
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Welcome to Traivox</h1>
      <p>Discover hidden global buyers and sellers – powered by AI.</p>
    </div>
  );
}

export default App;
